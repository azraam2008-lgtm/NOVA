// dil.ts - Uygulamanın altı dili
// Anahtar Türkçe metnin kendisidir (sitedeki t() ile aynı düzen).
// Sıra: [en, de, es, fr, ar]. Eksik çeviri olursa Türkçe gösterilir.

export type Dil = "tr" | "en" | "de" | "es" | "fr" | "ar";

export const DILLER: { kod: Dil; ad: string }[] = [
  { kod: "tr", ad: "Türkçe" },
  { kod: "en", ad: "English" },
  { kod: "de", ad: "Deutsch" },
  { kod: "es", ad: "Español" },
  { kod: "fr", ad: "Français" },
  { kod: "ar", ad: "العربية" },
];

const SIRA: Dil[] = ["en", "de", "es", "fr", "ar"];

const C: Record<string, [string, string, string, string, string]> = {
  // ------------------------------------------------------------ genel
  "Devam": ["Continue", "Weiter", "Continuar", "Continuer", "متابعة"],
  "Geri": ["Back", "Zurück", "Atrás", "Retour", "رجوع"],
  "İleri": ["Next", "Weiter", "Siguiente", "Suivant", "التالي"],
  "Kapat": ["Close", "Schließen", "Cerrar", "Fermer", "إغلاق"],
  "Yükleniyor...": ["Loading...", "Wird geladen...", "Cargando...", "Chargement...", "جارٍ التحميل..."],
  "Bir sorun çıktı. Biraz sonra tekrar dene.": ["Something went wrong. Please try again shortly.", "Etwas ist schiefgelaufen. Bitte versuche es gleich noch einmal.", "Algo salió mal. Vuelve a intentarlo en un momento.", "Un problème est survenu. Réessaie dans un instant.", "حدث خطأ ما. حاول مرة أخرى بعد قليل."],
  "ZARAFET VE DENGE": ["GRACE AND BALANCE", "ANMUT UND BALANCE", "ELEGANCIA Y EQUILIBRIO", "GRÂCE ET ÉQUILIBRE", "أناقة وتوازن"],

  // ------------------------------------------------------------ dil
  "Hangi dili kullanmak istersin?": ["Which language would you like to use?", "Welche Sprache möchtest du verwenden?", "¿Qué idioma quieres usar?", "Quelle langue veux-tu utiliser ?", "ما اللغة التي تريد استخدامها؟"],
  "Nova'yı bu dilde kullanacaksın. Daha sonra ayarlardan değiştirebilirsin.": ["You will use Nova in this language. You can change it later in settings.", "Du nutzt Nova in dieser Sprache. Du kannst sie später in den Einstellungen ändern.", "Usarás Nova en este idioma. Puedes cambiarlo más tarde en los ajustes.", "Tu utiliseras Nova dans cette langue. Tu pourras la changer plus tard dans les réglages.", "ستستخدم Nova بهذه اللغة. يمكنك تغييرها لاحقًا من الإعدادات."],

  // ------------------------------------------------------------ giriş
  "Giriş Yap": ["Sign in", "Anmelden", "Iniciar sesión", "Se connecter", "تسجيل الدخول"],
  "Kayıt Ol": ["Sign up", "Registrieren", "Registrarse", "S'inscrire", "إنشاء حساب"],
  "Kullanıcı adı veya e-posta": ["Username or email", "Benutzername oder E-Mail", "Usuario o correo", "Nom d'utilisateur ou e-mail", "اسم المستخدم أو البريد الإلكتروني"],
  "Kullanıcı adı": ["Username", "Benutzername", "Nombre de usuario", "Nom d'utilisateur", "اسم المستخدم"],
  "E-posta (isteğe bağlı, şifreni unutursan gerekli)": ["Email (optional, needed if you forget your password)", "E-Mail (optional, nötig, falls du dein Passwort vergisst)", "Correo (opcional, necesario si olvidas tu contraseña)", "E-mail (facultatif, utile si tu oublies ton mot de passe)", "البريد الإلكتروني (اختياري، تحتاجه إذا نسيت كلمة المرور)"],
  "Şifre": ["Password", "Passwort", "Contraseña", "Mot de passe", "كلمة المرور"],
  "Şifre (en az 8 karakter, bir büyük harf ve bir rakam)": ["Password (at least 8 characters, one capital letter and one number)", "Passwort (mind. 8 Zeichen, ein Großbuchstabe und eine Zahl)", "Contraseña (mínimo 8 caracteres, una mayúscula y un número)", "Mot de passe (8 caractères min., une majuscule et un chiffre)", "كلمة المرور (8 أحرف على الأقل، حرف كبير ورقم)"],
  "Hatalı kullanıcı adı veya şifre.": ["Incorrect username or password.", "Benutzername oder Passwort falsch.", "Usuario o contraseña incorrectos.", "Nom d'utilisateur ou mot de passe incorrect.", "اسم المستخدم أو كلمة المرور غير صحيحة."],
  "Çok fazla yanlış deneme. Yarın tekrar dene ya da şifreni sıfırla.": ["Too many wrong attempts. Try again tomorrow or reset your password.", "Zu viele Fehlversuche. Versuche es morgen erneut oder setze dein Passwort zurück.", "Demasiados intentos fallidos. Inténtalo mañana o restablece tu contraseña.", "Trop de tentatives. Réessaie demain ou réinitialise ton mot de passe.", "محاولات خاطئة كثيرة. حاول غدًا أو أعد تعيين كلمة المرور."],
  "Bu kullanıcı adı zaten alınmış.": ["This username is already taken.", "Dieser Benutzername ist schon vergeben.", "Este nombre de usuario ya está en uso.", "Ce nom d'utilisateur est déjà pris.", "اسم المستخدم هذا مستخدم بالفعل."],
  "Bu e-posta ile kayıtlı bir hesap var.": ["An account with this email already exists.", "Mit dieser E-Mail gibt es bereits ein Konto.", "Ya existe una cuenta con este correo.", "Un compte existe déjà avec cet e-mail.", "يوجد حساب مسجّل بهذا البريد الإلكتروني."],
  "Kullanıcı adı 3-30 karakter olmalı; harf, rakam, nokta ve tire kullanabilirsin.": ["Username must be 3-30 characters; letters, numbers, dots and hyphens are allowed.", "Der Benutzername muss 3-30 Zeichen haben; Buchstaben, Zahlen, Punkte und Bindestriche sind erlaubt.", "El usuario debe tener 3-30 caracteres; letras, números, puntos y guiones.", "Le nom d'utilisateur doit faire 3 à 30 caractères : lettres, chiffres, points et tirets.", "يجب أن يكون اسم المستخدم من 3 إلى 30 حرفًا؛ أحرف وأرقام ونقاط وشرطات."],
  "E-posta adresi geçerli görünmüyor.": ["The email address doesn't look valid.", "Die E-Mail-Adresse scheint ungültig zu sein.", "El correo no parece válido.", "L'adresse e-mail ne semble pas valide.", "يبدو أن البريد الإلكتروني غير صالح."],
  "Şifre en az 8 karakter olmalıdır.": ["Password must be at least 8 characters.", "Das Passwort muss mindestens 8 Zeichen haben.", "La contraseña debe tener al menos 8 caracteres.", "Le mot de passe doit contenir au moins 8 caractères.", "يجب أن تتكون كلمة المرور من 8 أحرف على الأقل."],
  "Şifre en az bir büyük harf içermelidir.": ["Password must contain at least one capital letter.", "Das Passwort muss mindestens einen Großbuchstaben enthalten.", "La contraseña debe tener al menos una mayúscula.", "Le mot de passe doit contenir au moins une majuscule.", "يجب أن تحتوي كلمة المرور على حرف كبير واحد على الأقل."],
  "Şifre en az bir rakam içermelidir.": ["Password must contain at least one number.", "Das Passwort muss mindestens eine Zahl enthalten.", "La contraseña debe tener al menos un número.", "Le mot de passe doit contenir au moins un chiffre.", "يجب أن تحتوي كلمة المرور على رقم واحد على الأقل."],
  "Giriş servisine şu an ulaşılamadı. Biraz sonra tekrar dene.": ["The sign-in service is unreachable right now. Please try again shortly.", "Der Anmeldedienst ist gerade nicht erreichbar. Bitte versuche es gleich noch einmal.", "El servicio de inicio de sesión no está disponible ahora. Vuelve a intentarlo en un momento.", "Le service de connexion est momentanément indisponible. Réessaie dans un instant.", "خدمة تسجيل الدخول غير متاحة الآن. حاول مرة أخرى بعد قليل."],
  "Hesabın hazırlanamadı. Bir kez siteden giriş yapıp tekrar dene.": ["Your account couldn't be prepared. Sign in once on the website, then try again.", "Dein Konto konnte nicht vorbereitet werden. Melde dich einmal auf der Website an und versuche es erneut.", "No se pudo preparar tu cuenta. Inicia sesión una vez en la web y vuelve a intentarlo.", "Ton compte n'a pas pu être préparé. Connecte-toi une fois sur le site, puis réessaie.", "تعذّر تجهيز حسابك. سجّل الدخول مرة من الموقع ثم حاول مجددًا."],

  // ------------------------------------------------------------ kurulum
  "Merhaba! Adın nedir?": ["Hi! What's your name?", "Hallo! Wie heißt du?", "¡Hola! ¿Cómo te llamas?", "Salut ! Comment t'appelles-tu ?", "مرحبًا! ما اسمك؟"],
  "Adın": ["Your name", "Dein Name", "Tu nombre", "Ton prénom", "اسمك"],
  "Lütfen adını gir.": ["Please enter your name.", "Bitte gib deinen Namen ein.", "Escribe tu nombre.", "Indique ton prénom.", "يرجى إدخال اسمك."],
  "Nova'yı hangi amaçla kullanmak istiyorsun?": ["What would you like to use Nova for?", "Wofür möchtest du Nova nutzen?", "¿Para qué quieres usar Nova?", "Pour quoi veux-tu utiliser Nova ?", "لأي غرض تريد استخدام Nova؟"],
  "Birden fazla seçebilirsin.": ["You can choose more than one.", "Du kannst mehrere auswählen.", "Puedes elegir más de uno.", "Tu peux en choisir plusieurs.", "يمكنك اختيار أكثر من واحد."],
  "Kilo vermek istiyorum": ["Lose weight", "Abnehmen", "Perder peso", "Perdre du poids", "إنقاص الوزن"],
  "Kilomu korumak istiyorum": ["Maintain my weight", "Gewicht halten", "Mantener mi peso", "Maintenir mon poids", "الحفاظ على وزني"],
  "Kilo almak istiyorum": ["Gain weight", "Zunehmen", "Ganar peso", "Prendre du poids", "زيادة الوزن"],
  "Kas kazanmak istiyorum": ["Build muscle", "Muskeln aufbauen", "Ganar músculo", "Prendre du muscle", "بناء العضلات"],
  "Sağlıklı beslenmek istiyorum": ["Eat healthier", "Gesünder essen", "Comer más sano", "Manger plus sainement", "تناول طعام صحي"],
  "Cinsiyetin nedir?": ["What is your sex?", "Was ist dein Geschlecht?", "¿Cuál es tu sexo?", "Quel est ton sexe ?", "ما جنسك؟"],
  "Kadın": ["Female", "Weiblich", "Mujer", "Femme", "أنثى"],
  "Erkek": ["Male", "Männlich", "Hombre", "Homme", "ذكر"],
  "Cinsiyetin, günlük enerji ihtiyacını hesaplamamızı doğrudan etkiler.": ["Your sex directly affects how we calculate your daily energy needs.", "Dein Geschlecht beeinflusst direkt die Berechnung deines täglichen Energiebedarfs.", "Tu sexo influye directamente en el cálculo de tu energía diaria.", "Ton sexe influe directement sur le calcul de tes besoins énergétiques.", "يؤثر جنسك مباشرة في حساب احتياجك اليومي من الطاقة."],
  "Doğum yılın ne?": ["What year were you born?", "In welchem Jahr bist du geboren?", "¿En qué año naciste?", "En quelle année es-tu né(e) ?", "في أي سنة وُلدت؟"],
  "yaşındasın": ["years old", "Jahre alt", "años", "ans", "سنة"],
  "18 yaşından küçüksün. Büyüme çağında kalori kısıtlamak gelişimi etkileyebilir; kilo hedefi koymadan önce bir doktora ya da diyetisyene danışmanı öneririm.": ["You are under 18. Restricting calories while growing can affect development; please talk to a doctor or dietitian before setting a weight goal.", "Du bist unter 18. Kalorien im Wachstum einzuschränken kann die Entwicklung beeinträchtigen; sprich vor einem Gewichtsziel mit einer Ärztin oder Ernährungsberatung.", "Tienes menos de 18 años. Restringir calorías en la etapa de crecimiento puede afectar el desarrollo; consulta a un médico o dietista antes de fijar un objetivo de peso.", "Tu as moins de 18 ans. Restreindre les calories pendant la croissance peut nuire au développement ; parle à un médecin ou un diététicien avant de fixer un objectif de poids.", "عمرك أقل من 18 عامًا. تقليل السعرات في مرحلة النمو قد يؤثر على التطور؛ استشر طبيبًا أو أخصائي تغذية قبل تحديد هدف للوزن."],
  "Boyun kaç?": ["How tall are you?", "Wie groß bist du?", "¿Cuánto mides?", "Quelle est ta taille ?", "كم طولك؟"],
  "Boy (cm)": ["Height (cm)", "Größe (cm)", "Altura (cm)", "Taille (cm)", "الطول (سم)"],
  "Şu andaki kilon ne?": ["What is your current weight?", "Wie viel wiegst du aktuell?", "¿Cuál es tu peso actual?", "Quel est ton poids actuel ?", "ما وزنك الحالي؟"],
  "Kilo (kg)": ["Weight (kg)", "Gewicht (kg)", "Peso (kg)", "Poids (kg)", "الوزن (كغ)"],
  "Hedef kilon nedir?": ["What is your goal weight?", "Was ist dein Zielgewicht?", "¿Cuál es tu peso objetivo?", "Quel est ton poids cible ?", "ما وزنك المستهدف؟"],
  "Hedef kilo (kg)": ["Goal weight (kg)", "Zielgewicht (kg)", "Peso objetivo (kg)", "Poids cible (kg)", "الوزن المستهدف (كغ)"],
  "Kaç ayda?": ["In how many months?", "In wie vielen Monaten?", "¿En cuántos meses?", "En combien de mois ?", "خلال كم شهر؟"],
  "Günlük hareket düzeyin": ["Your daily activity level", "Dein tägliches Aktivitätsniveau", "Tu nivel de actividad diario", "Ton niveau d'activité quotidien", "مستوى نشاطك اليومي"],
  "Hareketsiz (masa başı, çok az yürüyüş)": ["Sedentary (desk job, very little walking)", "Inaktiv (Bürojob, kaum Gehen)", "Sedentario (trabajo de oficina, poco caminar)", "Sédentaire (travail de bureau, très peu de marche)", "قليل الحركة (عمل مكتبي، مشي قليل جدًا)"],
  "Az hareketli (haftada 1-3 gün egzersiz)": ["Lightly active (exercise 1-3 days a week)", "Leicht aktiv (1-3 Tage Sport pro Woche)", "Poco activo (ejercicio 1-3 días por semana)", "Peu actif (sport 1 à 3 jours par semaine)", "نشاط خفيف (تمرين 1-3 أيام أسبوعيًا)"],
  "Orta hareketli (haftada 3-5 gün egzersiz)": ["Moderately active (exercise 3-5 days a week)", "Mäßig aktiv (3-5 Tage Sport pro Woche)", "Moderadamente activo (ejercicio 3-5 días por semana)", "Modérément actif (sport 3 à 5 jours par semaine)", "نشاط متوسط (تمرين 3-5 أيام أسبوعيًا)"],
  "Çok hareketli (haftada 6-7 gün egzersiz)": ["Very active (exercise 6-7 days a week)", "Sehr aktiv (6-7 Tage Sport pro Woche)", "Muy activo (ejercicio 6-7 días por semana)", "Très actif (sport 6 à 7 jours par semaine)", "نشاط عالٍ (تمرين 6-7 أيام أسبوعيًا)"],
  "Bu tempo hızlı. Güvenli aralık genelde haftada 0,5-1 kilodur; süreyi uzatmanı öneririm.": ["This pace is fast. The safe range is usually 0.5-1 kg per week; consider giving yourself more time.", "Dieses Tempo ist hoch. Sicher sind meist 0,5-1 kg pro Woche; plane lieber mehr Zeit ein.", "Este ritmo es rápido. Lo seguro suele ser 0,5-1 kg por semana; te sugiero alargar el plazo.", "Ce rythme est rapide. La plage sûre est généralement de 0,5 à 1 kg par semaine ; allonge plutôt la durée.", "هذه الوتيرة سريعة. النطاق الآمن عادةً 0.5-1 كغ أسبوعيًا؛ أنصحك بإطالة المدة."],
  "Günlük hedefin": ["Your daily target", "Dein Tagesziel", "Tu objetivo diario", "Ton objectif quotidien", "هدفك اليومي"],
  "Dinlenik metabolizman": ["Resting metabolism", "Grundumsatz", "Metabolismo en reposo", "Métabolisme de base", "معدل الأيض في الراحة"],
  "Tahmini günlük harcaman": ["Estimated daily burn", "Geschätzter Tagesverbrauch", "Gasto diario estimado", "Dépense quotidienne estimée", "الحرق اليومي المقدّر"],
  "Nova bir sağlık uygulaması değildir ve tıbbi tavsiye vermez. Hesaplamalar genel formüllere dayanan tahminlerdir.": ["Nova is not a medical app and does not give medical advice. Calculations are estimates based on general formulas.", "Nova ist keine medizinische App und gibt keine medizinischen Ratschläge. Berechnungen sind Schätzungen auf Basis allgemeiner Formeln.", "Nova no es una app médica y no da consejo médico. Los cálculos son estimaciones basadas en fórmulas generales.", "Nova n'est pas une application médicale et ne donne pas d'avis médical. Les calculs sont des estimations fondées sur des formules générales.", "Nova ليست تطبيقًا طبيًا ولا تقدم نصائح طبية. الحسابات تقديرات مبنية على معادلات عامة."],
  "Uygulamaya başla": ["Start using Nova", "Los geht's", "Empezar", "Commencer", "ابدأ"],

  // ------------------------------------------------------------ ana ekran
  "Merhaba": ["Hi", "Hallo", "Hola", "Salut", "مرحبًا"],
  "kcal kaldı": ["kcal left", "kcal übrig", "kcal restantes", "kcal restantes", "سعرة متبقية"],
  "kcal fazla": ["kcal over", "kcal zu viel", "kcal de más", "kcal en trop", "سعرة زائدة"],
  "Alınan": ["Eaten", "Gegessen", "Consumido", "Consommé", "المتناول"],
  "Hedef": ["Target", "Ziel", "Objetivo", "Objectif", "الهدف"],
  "Protein": ["Protein", "Eiweiß", "Proteína", "Protéines", "بروتين"],
  "Karbonhidrat": ["Carbs", "Kohlenhydrate", "Carbohidratos", "Glucides", "كربوهيدرات"],
  "Yağ": ["Fat", "Fett", "Grasa", "Lipides", "دهون"],
  "Su": ["Water", "Wasser", "Agua", "Eau", "ماء"],
  "bardak": ["glasses", "Gläser", "vasos", "verres", "أكواب"],
  "Kahvaltı": ["Breakfast", "Frühstück", "Desayuno", "Petit-déjeuner", "الإفطار"],
  "Öğle Yemeği": ["Lunch", "Mittagessen", "Almuerzo", "Déjeuner", "الغداء"],
  "Akşam Yemeği": ["Dinner", "Abendessen", "Cena", "Dîner", "العشاء"],
  "Ara Öğün": ["Snack", "Snack", "Tentempié", "Collation", "وجبة خفيفة"],
  "Sahur": ["Suhoor", "Sahur", "Suhur", "Shour", "السحور"],
  "İftar": ["Iftar", "Iftar", "Iftar", "Iftar", "الإفطار"],
  "Gece Ara Öğünü": ["Late-night snack", "Spätsnack", "Tentempié nocturno", "Collation du soir", "وجبة ليلية"],
  "Henüz bir şey eklemedin.": ["Nothing added yet.", "Noch nichts hinzugefügt.", "Aún no has añadido nada.", "Rien d'ajouté pour l'instant.", "لم تضف شيئًا بعد."],
  "Ekle": ["Add", "Hinzufügen", "Añadir", "Ajouter", "إضافة"],
  "Çıkış yap": ["Sign out", "Abmelden", "Cerrar sesión", "Se déconnecter", "تسجيل الخروج"],
  "Sil": ["Delete", "Löschen", "Eliminar", "Supprimer", "حذف"],

  // ------------------------------------------------------------ ekle paneli
  "Ne eklemek istersin?": ["What would you like to add?", "Was möchtest du hinzufügen?", "¿Qué quieres añadir?", "Que veux-tu ajouter ?", "ماذا تريد أن تضيف؟"],
  "Ara": ["Search", "Suchen", "Buscar", "Rechercher", "بحث"],
  "Barkod": ["Barcode", "Barcode", "Código de barras", "Code-barres", "باركود"],
  "Fotoğraf": ["Photo", "Foto", "Foto", "Photo", "صورة"],
  "Yazarak anlat": ["Describe it", "Beschreiben", "Descríbelo", "Décris-le", "صِف ما أكلت"],
  "Tarif": ["Recipe", "Rezept", "Receta", "Recette", "وصفة"],
  "Yakında": ["Coming soon", "Bald verfügbar", "Próximamente", "Bientôt", "قريبًا"],
  "Yemek ara": ["Search food", "Lebensmittel suchen", "Buscar comida", "Rechercher un aliment", "ابحث عن طعام"],
  "Bulamadım. \"Yazarak anlat\" seçeneğini dene.": ["Not found. Try \"Describe it\".", "Nichts gefunden. Versuche \"Beschreiben\".", "No encontrado. Prueba \"Descríbelo\".", "Introuvable. Essaie \"Décris-le\".", "لم أجد شيئًا. جرّب \"صِف ما أكلت\"."],
  "gram": ["grams", "Gramm", "gramos", "grammes", "غرام"],
  "Hangi öğün?": ["Which meal?", "Welche Mahlzeit?", "¿Qué comida?", "Quel repas ?", "أي وجبة؟"],
  "Eklendi": ["Added", "Hinzugefügt", "Añadido", "Ajouté", "تمت الإضافة"],
  "Ne yediğini anlat": ["Tell Nova what you ate", "Erzähl, was du gegessen hast", "Cuenta qué comiste", "Raconte ce que tu as mangé", "أخبرني بما أكلت"],
  "Örnek: 2 yumurta, 1 dilim peynir ve bir bardak çay": ["Example: 2 eggs, a slice of cheese and a cup of tea", "Beispiel: 2 Eier, eine Scheibe Käse und eine Tasse Tee", "Ejemplo: 2 huevos, una loncha de queso y una taza de té", "Exemple : 2 œufs, une tranche de fromage et une tasse de thé", "مثال: بيضتان، شريحة جبن وكوب شاي"],
  "Hesapla": ["Calculate", "Berechnen", "Calcular", "Calculer", "احسب"],
  "Nova hesaplıyor...": ["Nova is calculating...", "Nova rechnet...", "Nova está calculando...", "Nova calcule...", "Nova تحسب..."],
  "Bunları ekle": ["Add these", "Diese hinzufügen", "Añadir estos", "Ajouter ceux-ci", "أضف هذه"],
  "Bu bir yiyecek gibi görünmüyor.": ["That doesn't look like food.", "Das scheint kein Essen zu sein.", "Eso no parece comida.", "Ça ne ressemble pas à de la nourriture.", "لا يبدو هذا طعامًا."],
  "Bugünkü hakkın doldu. Yarın tekrar dene.": ["You've used today's allowance. Try again tomorrow.", "Dein heutiges Kontingent ist aufgebraucht. Versuche es morgen erneut.", "Has agotado tu límite de hoy. Vuelve mañana.", "Ton quota du jour est épuisé. Réessaie demain.", "استنفدت حصتك اليوم. حاول غدًا."],
  "Tahmin": ["Estimate", "Schätzung", "Estimación", "Estimation", "تقدير"],

  // ------------------------------------------------------------ asistan
  "Nova'ya sor": ["Ask Nova", "Frag Nova", "Pregunta a Nova", "Demande à Nova", "اسأل Nova"],
  "Bir şey sor...": ["Ask something...", "Frag etwas...", "Pregunta algo...", "Pose une question...", "اسأل شيئًا..."],
  "Gönder": ["Send", "Senden", "Enviar", "Envoyer", "إرسال"],
  "Beslenme ve antrenman soruların için. Genel bilgi verir, tıbbi tavsiye değildir.": ["For your nutrition and training questions. General information, not medical advice.", "Für deine Fragen zu Ernährung und Training. Allgemeine Infos, keine medizinische Beratung.", "Para tus dudas de nutrición y entrenamiento. Información general, no consejo médico.", "Pour tes questions de nutrition et d'entraînement. Informations générales, pas un avis médical.", "لأسئلتك عن التغذية والتمارين. معلومات عامة وليست نصيحة طبية."],
  "Nova yazıyor...": ["Nova is typing...", "Nova schreibt...", "Nova está escribiendo...", "Nova écrit...", "Nova تكتب..."],
  "Asistanı aç": ["Open assistant", "Assistent öffnen", "Abrir asistente", "Ouvrir l'assistant", "افتح المساعد"],

  // ------------------------------------------------------------ sekmeler ve temalar
  "Bugün": ["Today", "Heute", "Hoy", "Aujourd'hui", "اليوم"],
  "Gelişim": ["Progress", "Fortschritt", "Progreso", "Progrès", "التقدم"],
  "Antrenman": ["Workout", "Training", "Entreno", "Entraînement", "التمرين"],
  "Profil": ["Profile", "Profil", "Perfil", "Profil", "الملف الشخصي"],
  "Vazgeç": ["Cancel", "Abbrechen", "Cancelar", "Annuler", "إلغاء"],
  "Nova deneyimin için bir tema seç": ["Choose a theme for your Nova experience", "Wähle ein Design für dein Nova-Erlebnis", "Elige un tema para tu experiencia Nova", "Choisis un thème pour ton expérience Nova", "اختر سمة لتجربتك مع Nova"],
  "Koyu Cam": ["Dark Glass", "Dunkles Glas", "Cristal oscuro", "Verre sombre", "زجاج داكن"],
  "Yakut Kızılı": ["Ruby Red", "Rubinrot", "Rojo rubí", "Rouge rubis", "أحمر ياقوتي"],
  "Turkuaz Ferahlığı": ["Turquoise Breeze", "Türkisfrische", "Brisa turquesa", "Fraîcheur turquoise", "نسيم فيروزي"],
  "Altın Zarafet": ["Golden Elegance", "Goldene Eleganz", "Elegancia dorada", "Élégance dorée", "أناقة ذهبية"],
  "Bordo Kadife": ["Burgundy Velvet", "Bordeaux-Samt", "Terciopelo burdeos", "Velours bordeaux", "مخمل عنابي"],
  "Derin Mavi": ["Deep Blue", "Tiefblau", "Azul profundo", "Bleu profond", "أزرق عميق"],
  "Tema": ["Theme", "Design", "Tema", "Thème", "السمة"],
  "Dil": ["Language", "Sprache", "Idioma", "Langue", "اللغة"],

  // ------------------------------------------------------------ bugün
  "Yediklerin": ["Eaten", "Gegessen", "Consumido", "Consommé", "ما تناولته"],
  "Hareketle kazandıkların": ["Earned by moving", "Durch Bewegung verdient", "Ganado con movimiento", "Gagné en bougeant", "ما كسبته بالحركة"],

  // ------------------------------------------------------------ gelişim
  "Son 7 gün": ["Last 7 days", "Letzte 7 Tage", "Últimos 7 días", "7 derniers jours", "آخر 7 أيام"],
  "Son 30 gün": ["Last 30 days", "Letzte 30 Tage", "Últimos 30 días", "30 derniers jours", "آخر 30 يومًا"],
  "Günlük kalori": ["Daily calories", "Tägliche Kalorien", "Calorías diarias", "Calories quotidiennes", "السعرات اليومية"],
  "Ortalama": ["Average", "Durchschnitt", "Promedio", "Moyenne", "المتوسط"],
  "Kayıt girilen gün": ["Days logged", "Erfasste Tage", "Días registrados", "Jours saisis", "الأيام المسجلة"],
  "Hedefin altında": ["Under target", "Unter dem Ziel", "Bajo el objetivo", "Sous l'objectif", "تحت الهدف"],
  "Kilo": ["Weight", "Gewicht", "Peso", "Poids", "الوزن"],
  "Şimdi": ["Now", "Jetzt", "Ahora", "Maintenant", "الآن"],
  "Hedefe kalan": ["To go", "Noch übrig", "Falta", "Restant", "المتبقي"],
  "İlk kayıttan bu yana": ["Since first entry", "Seit dem ersten Eintrag", "Desde el primer registro", "Depuis la première saisie", "منذ أول تسجيل"],
  "Bugünkü kilon (kg)": ["Today's weight (kg)", "Heutiges Gewicht (kg)", "Peso de hoy (kg)", "Poids du jour (kg)", "وزن اليوم (كغ)"],
  "Kilomu kaydet": ["Save my weight", "Gewicht speichern", "Guardar mi peso", "Enregistrer mon poids", "احفظ وزني"],
  "Kaydedildi": ["Saved", "Gespeichert", "Guardado", "Enregistré", "تم الحفظ"],
  "Henüz kilo kaydın yok.": ["No weight entries yet.", "Noch keine Gewichtseinträge.", "Aún no hay registros de peso.", "Aucune pesée pour l'instant.", "لا توجد تسجيلات للوزن بعد."],
  "Ortalama makrolar": ["Average macros", "Durchschnittliche Makros", "Macros promedio", "Macros moyennes", "متوسط المغذيات"],

  // ------------------------------------------------------------ antrenman
  "Bugünkü hareketin": ["Today's activity", "Heutige Aktivität", "Actividad de hoy", "Activité du jour", "نشاط اليوم"],
  "Adım": ["Steps", "Schritte", "Pasos", "Pas", "الخطوات"],
  "Egzersiz (kcal)": ["Exercise (kcal)", "Training (kcal)", "Ejercicio (kcal)", "Exercice (kcal)", "التمرين (سعرة)"],
  "Kaydet": ["Save", "Speichern", "Guardar", "Enregistrer", "حفظ"],
  "Hareket kütüphanesi": ["Exercise library", "Übungsbibliothek", "Biblioteca de ejercicios", "Bibliothèque d'exercices", "مكتبة التمارين"],
  "Hepsi": ["All", "Alle", "Todos", "Tous", "الكل"],
  "Ekipmansız": ["No equipment", "Ohne Geräte", "Sin equipo", "Sans matériel", "بدون معدات"],
  "Dambıl": ["Dumbbells", "Kurzhanteln", "Mancuernas", "Haltères", "الدمبل"],
  "Barfiks barı": ["Pull-up bar", "Klimmzugstange", "Barra de dominadas", "Barre de traction", "عقلة"],
  "Başlangıç": ["Beginner", "Anfänger", "Principiante", "Débutant", "مبتدئ"],
  "Orta": ["Intermediate", "Mittel", "Intermedio", "Intermédiaire", "متوسط"],
  "İleri seviye": ["Advanced", "Fortgeschritten", "Avanzado", "Avancé", "متقدم"],
  "set": ["sets", "Sätze", "series", "séries", "مجموعات"],
  "Hareket videosu yakında burada olacak.": ["The exercise video will be here soon.", "Das Übungsvideo kommt bald hierher.", "El vídeo del ejercicio estará aquí pronto.", "La vidéo de l'exercice arrive bientôt ici.", "سيكون فيديو التمرين هنا قريبًا."],

  // ------------------------------------------------------------ profil
  "Yaş": ["Age", "Alter", "Edad", "Âge", "العمر"],
  "Boy": ["Height", "Größe", "Altura", "Taille", "الطول"],
  "Hedef kilo": ["Goal weight", "Zielgewicht", "Peso objetivo", "Poids cible", "الوزن المستهدف"],
  "Bilgilerimi güncelle": ["Update my details", "Meine Angaben ändern", "Actualizar mis datos", "Modifier mes informations", "حدّث بياناتي"],

  // ------------------------------------------------------------ ekle paneli (Aşama C, 1. parti)
  "Favori": ["Favorite", "Favorit", "Favorito", "Favori", "مفضّل"],
  "Favorilere ekle": ["Add to favorites", "Zu Favoriten", "Añadir a favoritos", "Ajouter aux favoris", "أضف إلى المفضلة"],
  "Favoriler": ["Favorites", "Favoriten", "Favoritos", "Favoris", "المفضلة"],
  "Tariflerim": ["My recipes", "Meine Rezepte", "Mis recetas", "Mes recettes", "وصفاتي"],
  "Kayıtlılarım": ["Saved", "Gespeichert", "Guardados", "Enregistrés", "المحفوظات"],
  "Yemek veritabanında": ["In the food database", "In der Lebensmitteldatenbank", "En la base de alimentos", "Dans la base d'aliments", "في قاعدة بيانات الأطعمة"],
  "Paketli ürünler": ["Packaged products", "Verpackte Produkte", "Productos envasados", "Produits emballés", "المنتجات المعبأة"],
  "Tabağını çek, Nova hesaplasın": ["Snap your plate, Nova does the math", "Fotografiere deinen Teller, Nova rechnet", "Fotografía tu plato y Nova calcula", "Photographie ton assiette, Nova calcule", "صوّر طبقك ودع Nova تحسب"],
  "Ne yediğini yaz": ["Type what you ate", "Schreib, was du gegessen hast", "Escribe lo que comiste", "Écris ce que tu as mangé", "اكتب ما أكلته"],
  "Favoriler ve tariflerin": ["Favorites and recipes", "Favoriten und Rezepte", "Favoritos y recetas", "Favoris et recettes", "المفضلة والوصفات"],
  "Malzemelerden kur": ["Build from ingredients", "Aus Zutaten erstellen", "Crear con ingredientes", "Créer à partir d'ingrédients", "أنشئها من المكونات"],
  "Ürün bilgisine şu an ulaşılamadı. Biraz sonra tekrar dene.": ["Product information is unavailable right now. Please try again shortly.", "Produktinfos sind gerade nicht erreichbar. Bitte versuche es gleich noch einmal.", "La información del producto no está disponible ahora. Inténtalo en un momento.", "Les infos produit sont indisponibles pour l'instant. Réessaie dans un instant.", "معلومات المنتج غير متاحة الآن. حاول مرة أخرى بعد قليل."],
  "Kamera ya da fotoğraf izni verilmedi. iPhone Ayarlar > Expo Go bölümünden açabilirsin.": ["Camera or photo access was not allowed. You can turn it on in iPhone Settings > Expo Go.", "Kamera- oder Fotozugriff wurde nicht erlaubt. Du kannst ihn unter iPhone-Einstellungen > Expo Go aktivieren.", "No se permitió el acceso a la cámara o fotos. Actívalo en Ajustes del iPhone > Expo Go.", "L'accès à l'appareil photo ou aux photos n'a pas été autorisé. Active-le dans Réglages > Expo Go.", "لم يُسمح بالوصول إلى الكاميرا أو الصور. يمكنك تفعيله من إعدادات iPhone > Expo Go."],
  "Etiketteki besin değerleri okunamadı. Daha yakından ve net çekmeyi dene.": ["Couldn't read the nutrition label. Try a closer, sharper photo.", "Die Nährwerttabelle war nicht lesbar. Versuche ein näheres, schärferes Foto.", "No se pudo leer la etiqueta. Prueba una foto más cercana y nítida.", "Impossible de lire l'étiquette. Essaie une photo plus proche et plus nette.", "تعذّرت قراءة الملصق الغذائي. جرّب صورة أقرب وأوضح."],
  "Gramları düzeltebilirsin; yanlış kalemi × ile çıkar.": ["You can fix the grams; remove a wrong item with ×.", "Du kannst die Gramm korrigieren; entferne Falsches mit ×.", "Puedes corregir los gramos; quita lo incorrecto con ×.", "Tu peux corriger les grammes ; retire un élément faux avec ×.", "يمكنك تعديل الغرامات؛ احذف العنصر الخاطئ بـ ×."],
  "Kamerayı aç": ["Turn on camera", "Kamera einschalten", "Activar cámara", "Activer l'appareil photo", "شغّل الكاميرا"],
  "Kamerayı ürünün barkoduna tut. Okumazsa numarayı elle yaz.": ["Point the camera at the barcode. If it won't scan, type the number.", "Halte die Kamera auf den Barcode. Klappt es nicht, tippe die Nummer ein.", "Apunta la cámara al código. Si no lo lee, escribe el número.", "Vise le code-barres. S'il n'est pas lu, tape le numéro.", "وجّه الكاميرا نحو الباركود. إن لم يُقرأ، اكتب الرقم."],
  "Bu ürün açık veritabanında yok ya da besin değerleri eksik. Arka yüzdeki besin değerleri tablosunun fotoğrafını çekersen Nova okusun.": ["This product isn't in the open database or its values are incomplete. Take a photo of the nutrition table on the back and Nova will read it.", "Dieses Produkt fehlt in der offenen Datenbank oder die Werte sind unvollständig. Fotografiere die Nährwerttabelle, Nova liest sie.", "Este producto no está en la base abierta o faltan valores. Fotografía la tabla nutricional y Nova la leerá.", "Ce produit n'est pas dans la base ouverte ou ses valeurs sont incomplètes. Photographie le tableau nutritionnel, Nova le lira.", "هذا المنتج غير موجود في القاعدة المفتوحة أو قيمه ناقصة. صوّر جدول القيم الغذائية وستقرؤه Nova."],
  "Etiketi fotoğrafla": ["Photograph the label", "Etikett fotografieren", "Fotografiar la etiqueta", "Photographier l'étiquette", "صوّر الملصق"],
  "Fotoğraf çek": ["Take photo", "Foto aufnehmen", "Hacer foto", "Prendre une photo", "التقط صورة"],
  "Galeriden seç": ["Choose from library", "Aus Mediathek", "Elegir de la galería", "Choisir dans la galerie", "اختر من المعرض"],
  "Tabağın tamamı görünsün; yanında çatal ya da bardak varsa Nova porsiyonu daha iyi tahmin eder.": ["Keep the whole plate in view; a fork or glass nearby helps Nova judge the portion.", "Der ganze Teller sollte zu sehen sein; Gabel oder Glas daneben helfen Nova bei der Portion.", "Que se vea todo el plato; un tenedor o vaso cerca ayuda a Nova con la porción.", "Garde toute l'assiette dans le cadre ; une fourchette ou un verre aide Nova à estimer la portion.", "اجعل الطبق كله ظاهرًا؛ وجود شوكة أو كوب بجانبه يساعد Nova في تقدير الحصة."],
  "Henüz favorin yok. Bir yemeği seçince yıldıza dokunarak favorilere ekleyebilirsin.": ["No favorites yet. Pick a food and tap the star to add it.", "Noch keine Favoriten. Wähle ein Lebensmittel und tippe auf den Stern.", "Aún no tienes favoritos. Elige un alimento y toca la estrella.", "Pas encore de favoris. Choisis un aliment et touche l'étoile.", "لا توجد مفضلة بعد. اختر طعامًا واضغط على النجمة."],
  "Henüz kayıtlı tarifin yok. Tarif bölümünden kurabilirsin.": ["No saved recipes yet. Build one in the Recipe section.", "Noch keine Rezepte. Erstelle eines im Bereich Rezept.", "Aún no hay recetas. Crea una en la sección Receta.", "Pas encore de recettes. Crée-en une dans la section Recette.", "لا توجد وصفات محفوظة بعد. أنشئ واحدة من قسم الوصفة."],
  "Birden çok parçadan oluşan bir yemeği bir kez kur, kaydet; sonra tek dokunuşla ekle.": ["Build a multi-part meal once, save it, then add it with one tap.", "Stelle ein Gericht aus mehreren Teilen einmal zusammen, speichere es und füge es dann mit einem Tipp hinzu.", "Crea una comida de varias partes una vez, guárdala y añádela con un toque.", "Compose un plat en plusieurs parties une fois, enregistre-le, puis ajoute-le d'une touche.", "أنشئ وجبة من عدة مكونات مرة واحدة واحفظها، ثم أضفها بلمسة."],
  "Malzeme ara": ["Search ingredients", "Zutat suchen", "Buscar ingrediente", "Rechercher un ingrédient", "ابحث عن مكوّن"],
  "Tarifin": ["Your recipe", "Dein Rezept", "Tu receta", "Ta recette", "وصفتك"],
  "Toplam": ["Total", "Gesamt", "Total", "Total", "المجموع"],
  "Kaç porsiyon?": ["Servings", "Portionen", "Raciones", "Portions", "عدد الحصص"],
  "Tarifin adı": ["Recipe name", "Rezeptname", "Nombre de la receta", "Nom de la recette", "اسم الوصفة"],
  "Bir porsiyon": ["One serving", "Eine Portion", "Una ración", "Une portion", "حصة واحدة"],
  "Bugüne ekle": ["Add to today", "Zu heute hinzufügen", "Añadir a hoy", "Ajouter à aujourd'hui", "أضف إلى اليوم"],
  "Tarifi kaydet": ["Save recipe", "Rezept speichern", "Guardar receta", "Enregistrer la recette", "احفظ الوصفة"],
  "Tarifin adını yaz.": ["Enter the recipe name.", "Gib den Rezeptnamen ein.", "Escribe el nombre de la receta.", "Indique le nom de la recette.", "اكتب اسم الوصفة."],
  "kaydedildi. Artık aramada çıkacak.": ["saved. It will now show up in search.", "gespeichert. Es erscheint jetzt in der Suche.", "guardada. Ahora aparecerá en la búsqueda.", "enregistrée. Elle apparaîtra désormais dans la recherche.", "حُفظت. ستظهر الآن في البحث."],
  "Dünden kopyala": ["Copy from yesterday", "Von gestern kopieren", "Copiar de ayer", "Copier d'hier", "انسخ من الأمس"],
};

let aktif: Dil = "tr";
export function dilAyarla(d: Dil) {
  aktif = d;
}
export function aktifDil(): Dil {
  return aktif;
}
export function sagdanSola(): boolean {
  return aktif === "ar";
}
export function t(metin: string): string {
  if (aktif === "tr") return metin;
  const satir = C[metin];
  return satir ? satir[SIRA.indexOf(aktif)] : metin;
}
// Sınama için: hangi anahtarın hangi dilde boş kaldığını bulur
export function eksikCeviriler(): string[] {
  return Object.entries(C).filter(([, v]) => v.length !== 5 || v.some((x) => !x)).map(([k]) => k);
}

/** Cihaz dilinden başlangıç dili (yalnızca ilk açılışta önerilir). */
export function cihazDili(kod: string | undefined | null): Dil {
  const k = (kod ?? "").slice(0, 2).toLowerCase();
  return (["tr", "en", "de", "es", "fr", "ar"] as Dil[]).includes(k as Dil) ? (k as Dil) : "en";
}
