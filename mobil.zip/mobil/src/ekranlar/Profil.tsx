// Profil.tsx - "Profil" sekmesi: bilgiler, tema, dil, çıkış
import React from "react";
import { StyleSheet, View } from "react-native";
import { DILLER, aktifDil, t, type Dil } from "../dil";
import { hedefHesapla, yas, type Veri } from "../hesap";
import { VARSAYILAN_TEMA } from "../tema";
import { Cip, Dugme, Kart, R, SayfaBasligi, Yazi, temali } from "../bilesenler";
import { TemaSecici } from "./TemaSecici";

export function ProfilSayfasi(p: {
  veri: Veri; kullanici: string; temaSec: (ad: string) => void; dilSec: (d: Dil) => void; duzenle: () => void; cikis: () => void;
}) {
  const pr = p.veri.profil;
  const h = hedefHesapla(pr);
  const satir = (ad: string, deger: string) => (
    <View style={[s.satir, s.kalem]} key={ad}><Yazi tur="soluk">{t(ad)}</Yazi><Yazi>{deger}</Yazi></View>
  );
  return (
    <View testID="sayfa-profil">
      <SayfaBasligi baslik={t("Profil")} alt={`@${p.kullanici}`} />

      <Kart>
        <Yazi s={{ fontWeight: "700", fontSize: 17 }}>{pr.ad}</Yazi>
        {satir("Yaş", String(yas(pr)))}
        {satir("Boy", `${pr.boy} cm`)}
        {satir("Kilo", `${Number(pr.mevcut_kilo).toFixed(1)} kg`)}
        {satir("Hedef kilo", `${Number(pr.hedef_kilo).toFixed(1)} kg`)}
        {satir("Günlük hedefin", `${Math.round(h.hedef)} kcal`)}
        <Dugme testID="bilgileri-guncelle" tur="ikincil" yazi={t("Bilgilerimi güncelle")} bas={p.duzenle} s={{ marginTop: 14 }} />
      </Kart>

      <Kart>
        <Yazi s={{ fontWeight: "700", fontSize: 17, marginBottom: 12 }}>{t("Tema")}</Yazi>
        <TemaSecici secili={String(pr.tema ?? VARSAYILAN_TEMA)} sec={p.temaSec} />
      </Kart>

      <Kart>
        <Yazi s={{ fontWeight: "700", fontSize: 17, marginBottom: 12 }}>{t("Dil")}</Yazi>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {DILLER.map((d) => <Cip key={d.kod} testID={`dil-sec-${d.kod}`} yazi={d.ad} secili={aktifDil() === d.kod} bas={() => p.dilSec(d.kod)} />)}
        </View>
      </Kart>

      <Dugme testID="cikis" tur="yalin" yazi={t("Çıkış yap")} bas={p.cikis} />
      <Yazi tur="soluk" s={{ textAlign: "center", marginTop: 8 }}>{t("Nova bir sağlık uygulaması değildir ve tıbbi tavsiye vermez. Hesaplamalar genel formüllere dayanan tahminlerdir.")}</Yazi>
    </View>
  );
}

const s = temali(() => StyleSheet.create({
  satir: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  kalem: { marginTop: 10, paddingTop: 10, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: R.cizgi },
}));
